#!/usr/bin/bash


touch coucou.txt
echo "j'apprecie les fruits au sirop " >> coucou.txt
